# CYBER BOTS

2D pixel-art robot shooter in NEON CITY. Plain HTML5 + CSS3 + JavaScript, drawn on a canvas.
No libraries, no build step, no external requests. All graphics and sounds are generated in code.

## Deploy on Netlify
Drag this folder (or the ZIP) onto https://app.netlify.com/drop - no build settings needed.
The game also runs by simply opening `index.html` in a browser.

## Controls
| Key | Action |
| --- | --- |
| A / D | Move |
| Space | Jump (S = drop through platforms) |
| Mouse | Aim |
| Left mouse button | Shoot |
| Q (or E / Shift) | Special ability |
| F | Toggle auto-fire |
| ESC | Pause |

Phones and tablets get on-screen touch controls automatically (landscape mode).

### Xbox controller (Gamepad API, standard mapping)
Connect the controller and press any button once (browsers only expose it after that).

| Input | Action |
|---|---|
| Left stick / D-pad | Move |
| A | Jump |
| Right stick | Aim (crosshair is shown) |
| RT / RB | Shoot |
| B / X / LB | Special ability |
| Y | Toggle auto-fire |
| Start | Pause / resume |
| Menus: D-pad or left stick, A = select, B = back | |

Vibration can be switched off in SETTINGS. Unplugging the controller during a run pauses the game.

## Project structure
```
index.html          page, menus, HUD markup
css/style.css       neon UI styling, responsive layout, touch controls
js/config.js        robots, weapons, enemies, sectors, upgrades, themes (all balance values)
js/storage.js       LocalStorage save system (validated on load)
js/audio.js         Web Audio sound effects + synth music
js/input.js         keyboard, mouse, touch and gamepad input
js/sprites.js       procedural pixel-art sprites (robots, enemies, weapons)
js/background.js    parallax NEON CITY backgrounds, rain, signs, smoke, traffic
js/game.js          game logic (fixed 60 Hz timestep, frame-rate independent)
js/render.js        canvas drawing
js/ui.js            menus, HUD, shop, settings
js/main.js          boot + main loop
```

## Content
* 5 robots: Mini-Bot, Standard-Bot, Heavy-Bot, Titan-Bot, Colossus - each with own stats and special ability
* 5 weapons: Plasma Blaster, Double Blaster, Electro Cannon, Rocket Launcher, Plasma Cannon
* 5 enemy types + boss (Neon Warden) that detect, chase and attack the player
* 4 sectors in NEON CITY: Downtown, Factory Row, Core Tower (boss), Overdrive (endless)
* 5 upgrades with 10 levels each; progress is saved automatically in the browser
